import math

limit = 10**7

# Sieve of Eratosthenes
sieve = [True] * (limit + 1)
sieve[0] = sieve[1] = False

for i in range(2, int(math.sqrt(limit)) + 1):
    if sieve[i]:
        for j in range(i * i, limit + 1, i):
            sieve[j] = False

primes = [p for p in range(2, limit + 1) if sieve[p]]
primes = [p for p in primes if pow(3, p, 7) == 3 and p % 8 == 1 and p % 13 == 1]

print(len(primes))
print(primes)
