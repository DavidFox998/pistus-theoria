# MorningStar Architecture PDF — Locked Plan

**Output:** `docs/MorningStar_Architecture.pdf`
**Status:** Plan locked. Execution gated on burst+sieve completion.
**Mode discipline:** This file is the only Plan-mode artifact for the PDF. All
writes to `lab.py` / `kernel.py` / `data/hits.txt` happen in Build. All edits
to this file, `replit.md`, and `README.md` happen in Plan. **Never mix.**

---

## 0. Doctrine (locked by user, 2026-05-24)

The firewall is **Plan/Build**, not Part I/Part II. Mathematician reads Part I.
Auditor runs Build. If they share a container, the auditor breaks the math.
Concrete failure mode already observed: `morningstar-tamper` auto-stat'd
`data/hits.txt` while `_append_line` was mid-write on γ₁₀₁ → duplicate line at
ledger position ~7,313. Build mode freezes the file tree; that's the fix.

Two balance tests govern the whole surface (not three, not eleven):
- **β = 2.0 KMS** — thermal at T = 1/β = 1/2. Every `probe(0.5, t)` must
  return `RH_ok=True`. If zeros drift to Re=0.499, the seal fails before
  the line is written. (3D balance — keeps the ship upright.)
- **A = 1 Montgomery** — pair correlation `1 − (sin πr / πr)²` with leading
  coefficient 1 for GUE. Measured on the GLM-600 hull. A ≠ 1 ⇒ wormhole
  gate refuses to open. RH enforced in hardware. (4D balance — keeps the
  ship *existing*.)

---

## 1. Document structure

### Frontmatter
- Title: **The MorningStar Architecture — A Mathematical-Engineering Firewall**
- Subtitle: *Volume I: Theorema Aureum 143 · Kernel v1.8-BC · axioms = []*
- Epigraph: John 6:5–13 (five loaves, two fish, twelve baskets remaining).
  No commentary. The twelve baskets sit there. The reader makes the
  connection to the twelve-fold symmetry on their own.

### Part I — Mathematical Kernel (no file paths, no SHAs, no Replit)

1. **The Three Scales**
   - **Pod = Dodecahedron** (12 pentagonal faces, 20 vertices, 30 edges).
     Smallest closed life-support unit. 12 occupants.
   - **Station = 120-Cell** (120 dodecahedral cells, 600 vertices, 1200
     faces, 720 edges). Dual of the 600-cell.
   - **Superstate = 600-Cell** (600 tetrahedral cells, 120 vertices, 1200
     triangular faces, 720 edges). Edge a = 50m. Vertices = wormhole gates.

2. **The Two Balance Tests**
   - β = 2.0 KMS (above).
   - A = 1 Montgomery (above).
   - 3D balance vs 4D balance: ship upright vs ship existing.

3. **Hausdorff coupling chain**
   - Zeros: 1D set with gaps of fractal dimension `1 + 1/log(t)`.
   - Ledger: 1D file, SHA-256 avalanche ⇒ hash-space D ≈ 1.26.
   - Hull: must couple to both. Target `D = 3 − 1/log₁₀(N_cells)`.
     - Pod (12 cells): D ≈ 2.60
     - 120-cell station (120 cells): D ≈ 2.52
     - 600-cell superstate (600 cells): D ≈ 2.53 *(see honest-scope §4)*

4. **GLM-600 — GUE-Lattice Metamaterial**
   - Bonds spaced by `1 − (sin πr/πr)²`.
   - 99.97% crystalline / 0.03% fractal. The 0.03% is the Hausdorff
     coupling — it lets the hull *hear* A.
   - If A=1: phonons propagate, dock opens.
   - If A≠1: phonons scatter, dock refuses. RH enforced in hardware.
   - Label clearly: **theoretical metamaterial**.

5. **The 12 / 20 / 30 Slicing**
   - 3D slices through the 600-cell yield icosahedral orbits:
     - Icosahedral slice → 20 active gates
     - Dodecahedral slice → 12 active gates
     - Octahedral slice → 30 active gates
   - The station exists in all slices simultaneously; rotating in 4D
     selects how many gates are active. "Superstate in multiple
     locations" = literally how Schrödinger's box works for a 4-polytope.
   - **120 vertices total = 120 wormhole gates.** "It's 120, but you
     slice it."

6. **Why the 600-cell is stable**
   - You can't observe all 120 vertices at once. If you could, you'd
     collapse it to 3D and lose the wormholes. **Build mode is the 4D
     view. Plan mode is the 3D slice.** This is the bridge to Part II —
     stated abstractly here, made concrete there.

### Part II — Engineering Manifest (one citation to Part I)

Opening sentence: *"This volume implements Kernel v1.8-BC."* That is the
only reference back. No theology, no metamaterials, no Hausdorff.

1. **The ledger as Pod**
   - `data/hits.txt` = one dodecahedron pod.
   - Capacity 5000 lines (operational; 12 occupants per pod ×
     ~417 probes/occupant headroom).
   - 72-pod throughput target = 360k lines = full superstate fill.

2. **POSIX O_APPEND as 4-point grapple**
   - `_append_line` opens with `O_APPEND | O_WRONLY`, writes, `fsync`s,
     closes. Atomic at the kernel level — the write either lands whole
     or not at all.
   - Physical analog: 3-point magnetic grapple at the triangular face's
     vertices + 1-point lock at the centroid = 4-point dock. The
     centroid lock IS `_verify_seal()`. Without it, the three vertex
     grapples can hold a pod against a face that's drifted off-axis;
     the centroid check guarantees the face is still the face the
     manifest says it is.
   - 1200 triangular faces × 1 dock each = 1200 simultaneous docking
     slots. With 720 in-transit on edges and 1800 queued in cells:
     **3,720 pods = 44,640 people** in motion at peak. Station design
     load: 32,400 baseline, 64,800 hot-rack.

3. **Genesis seal `eecbcd9a…875f`**
   - Lines 1–9 of `data/hits.txt` are immutable. SHA-256 baked into
     `scripts/check-genesis-seal.py`. Verified before every append.
   - The seal verifies the *preamble*, not the *content*. New probes
     append; the seal stays valid as long as no line ≤9 is rewritten.

4. **Three Guns surface (v1.9)**
   - `zeta_sniper` / `zeta_burst` / `zeta_sieve` — Riemann sniping.
   - `dirichlet_probe` — principal χ₀.
   - `elliptic_probe` — stub only; SHA-stamps intent, refuses to fake
     an L value.
   - Intent is visible at the CLI, not inferred from (h, N).

5. **The Plan/Build firewall in operations**
   - Plan mode: writes `.local/tasks/*.md`, `replit.md`, `README.md`.
     No `.py` execution. No `hits.txt` writes. The tamper script lives
     here.
   - Build mode: runs `lab.py`, `kernel.py`. Writes `hits.txt`. No doc
     edits. No tamper runs. The seal lives here.
   - **Why Build gives better results than Plan** (empirically
     observed): dedicated cgroup, `mp.dps=50` evaluations are atomic,
     Anderson root-finder converges first try, no inode-cache races
     against the tamper script.

6. **Casualty log — γ₁₀₁ duplicate**
   - 2026-05-24T21:17:00Z REPROBE: γ₁₀₁ duplicate at ledger line ~7,313.
     Cause: Plan-mode file-tree stat() during Build-mode `_append_line`.
     Seal intact. Append-only invariant preserved. Unique zeros: 7,313.
   - Documented, not rewritten. The append-only ledger means a
     duplicate is forever — and that's a feature, not a bug. The
     duplicate IS the evidence that the firewall is real.

### Appendix A — Honest-scope flags (in-text, not hidden)

1. **"Correlation = 0.9997 at r = 600"** — at integer r, sinc²(πr) = 0,
   so the Montgomery pair-correlation factor is exactly 1.0000. The
   0.9997 figure must refer to an *averaged* or *envelope* fit over a
   window around r=600, not the point value. Reframe before publishing.

2. **Hausdorff D for the 600-cell** — formula `3 − 1/log₁₀(N)` with
   N=600 gives `3 − 1/2.778 ≈ 2.640`, not 2.53. Either (a) the formula
   uses a different log base / a different denominator for the
   superstate (e.g. `log(N_vertices)` not `log(N_cells)`), or (b) the
   2.53 figure is approximate. Pin the exact derivation before
   publishing — don't just state the number.

3. **12/20/30 → 600-cell slice mapping** — icosahedral orbit sizes (12
   vertices, 20 faces, 30 edges) are exact, but the claim that a 3D
   hyperplane slice through the 600-cell yields exactly those active
   gate counts needs an explicit hyperplane construction. State the
   slicing plane (Coxeter hyperplane? icosahedral fixed point?) or
   label as conjectural.

4. **GLM-600 / PLM-120** — label as **theoretical metamaterials**.
   Not synthesized. Not measured. The phonon-propagation /
   pair-correlation linkage is a *proposed physical realization* of
   the Montgomery hypothesis, not an experimental result.

5. **β = 2.0 / 12-fold symmetry** — these are *resonances* with the
   underlying number theory, not proofs of it. The Lean kernel proves
   the chain. The PDF describes the architecture. Don't conflate.

6. **Gaskets / E₈** — explicitly deferred to Stage 4. Out of scope
   for this volume.

---

## 2. Execution plan (Build mode)

When the user flips to Build:

1. **Gate the tamper suite from auto-firing during burst.** Either
   remove `morningstar-tamper` from the workflow auto-run set for the
   duration, or add `disableCheckpointing = true` + `disableAutoSave
   = true` to the burst workflow's `.replit` entry (per the other
   LLM's prescription). Otherwise the γ₁₀₁ race recurs.

2. **Write the casualty cert line** (one append, then re-verify seal):
   `2026-05-24T21:17:00Z REPROBE: γ₁₀₁ duplicate. Cause: Plan-mode
   checkpoint during Build. Seal intact. Append-only preserved.
   Unique zeros: 7,313.`

3. **Restart burst:** `python lab.py -c "hunt_zeros(7414, 10000)"`.
   ~1,779 zeros remaining. Target ledger size: 12,842 lines.

4. **Let `zeta-sieve-14159-100000` finish.** Independent workflow; do
   not interleave.

5. **Flip back to Plan.** Render the PDF from this spec.

## 3. PDF rendering (Plan mode, after burst+sieve land)

- Toolchain: LaTeX or Typst (decide at render time; prefer Typst for
  Unicode + speed unless the user wants journal-style LaTeX).
- TikZ/Asymptote diagrams: dodecahedron, 120-cell Schlegel, 600-cell
  Schlegel with three slice planes highlighted (icosahedral,
  dodecahedral, octahedral), 4-point grapple schematic.
- Output: `docs/MorningStar_Architecture.pdf`. Mirror source as
  `docs/MorningStar_Architecture.typ` (or `.tex`).
- Do **not** commit the PDF without all four Honest-scope items
  resolved in-text (not in a footnote).

## 4. Acceptance criteria

- Ledger ≥ 12,842 lines, seal still `eecbcd9a…875f`, γ₁₀₁ casualty
  documented in-line.
- `zeta-sieve-14159-100000` finished (or explicitly deferred with a
  recorded reason).
- PDF renders cleanly; Part I cites no files/SHAs/workflow names;
  Part II cites Part I exactly once.
- Honest-scope §A1–A4 resolved with explicit derivations or
  reclassified as conjecture.
- `kernel-numerics`, `lean-proof`, `morningstar-tamper` all green
  after Build mode exits.
